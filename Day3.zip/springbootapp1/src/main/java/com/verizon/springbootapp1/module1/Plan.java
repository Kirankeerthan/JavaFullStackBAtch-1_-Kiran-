package com.verizon.springbootapp1.module1;

public class Plan {
   int pid;
   String pname;
   int duration;
public Plan(int pid, String pname, int duration) {
	super();
	this.pid = pid;
	this.pname = pname;
	this.duration = duration;
}
@Override
public String toString() {
	return "Plan [pid=" + pid + ", pname=" + pname + ", duration=" + duration + "]";
}
public int getPid() {
	return pid;
}
public void setPid(int pid) {
	this.pid = pid;
}
public String getPname() {
	return pname;
}
public void setPname(String pname) {
	this.pname = pname;
}
public int getDuration() {
	return duration;
}
public void setDuration(int duration) {
	this.duration = duration;
}

}