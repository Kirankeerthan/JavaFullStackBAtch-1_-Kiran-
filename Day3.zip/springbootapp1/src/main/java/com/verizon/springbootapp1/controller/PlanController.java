package com.verizon.springbootapp1.controller;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.verizon.springbootapp1.module1.Plan;

@RestController
public class PlanController {
@GetMapping("/plan")
public String getDetails()
{
	return "plan  Details: 45";
}
@PostMapping("/plan")
public Plan addDetail(@RequestBody Plan p1)
{
	return p1;
}
@PutMapping("/plan")
public Plan updateDetails(@RequestBody Plan p2)
{
	return p2;
}
@DeleteMapping("/plan")
public String deleteDetails()
{
	return "plan is successfully deleted";
}
}
