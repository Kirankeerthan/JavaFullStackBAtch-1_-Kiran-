package Day3;

import java.util.Random;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class Functional {

	public static void main(String[] args) {
		Consumer<Integer> consume = (a) -> System.out.println("square of a number is:" + " " + (a * a));
		consume.accept(9);
		Consumer<String> str = (a) -> System.out.println("uppercase of a string" + " " + a.toUpperCase());
		str.accept("kiran");
		Consumer<Integer> var = (a) -> System.out.println(a * a);
		var.accept(2);
		Supplier<Integer> su = () -> new Random().nextInt(100);
		System.out.println(su.get());
		Predicate<Integer> pr = (a) -> a % 2 == 0;
		System.out.println(pr.test(7));
		Function<Integer,Integer> f=(a)->a*a*a;
		System.out.println(f.apply(5));
		Function<String,Integer> s = 
	}

}
