package Day3;

import java.util.StringJoiner;

public class StrJoin {
public static void main(String[] args) {
	StringJoiner jn = new StringJoiner(",");
	jn.add("ravi");
	jn.add("suma");
	System.out.println(jn);
	System.out.println(jn.length());
	StringJoiner s = new StringJoiner("-");
	s.add("python");
	s.add("java");
	System.out.println(jn.merge(s));
	System.out.println(s.merge(jn));
	}
}
