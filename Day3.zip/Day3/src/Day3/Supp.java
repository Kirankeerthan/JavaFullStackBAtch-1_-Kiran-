package Day3;

import java.util.Arrays;

import java.util.List;

public class Supp {
	public static void main(String[] args) {

		int a[] = { 1, 5, 8, 3, 6, 9 };
		for (int x : a)
			System.out.println(x + " ");

		Arrays.sort(a);
		for (int x : a)
			System.out.println(x + " ");

		int b[] = new int[5];
		Arrays.fill(b, 8);
		for (int x : b)
			System.out.println(x + " ");
		List<Integer> li = Arrays.asList(2, 34, 7, 8, 9, 0, 3, 4, 1);
		li.forEach(x -> System.out.println(x));
		System.out.println("::");
		li.forEach(System.out::print);

		li.stream().sorted().filter(x -> x <= 5).limit(8).forEach(x -> System.out.println(x+ " "));


	}

}
