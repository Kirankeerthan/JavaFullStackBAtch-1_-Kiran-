package Day3;
interface Arith{
	int getSum(int a, int b);
}
public class Lambda {
   public static void main(String[] args) {
	   
	Arith ar = (int a,int b)->{int c = a+b;return c;};
	System.out.println(ar.getSum(4, 5));
}
}
