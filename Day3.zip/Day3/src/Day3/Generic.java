package Day3;
interface Gener<T>
{
	T func(T a, T b);
}
public class Generic {
public static void main(String[] args) {
	Gener<Integer> arith = (a,b)->a+b;
	System.out.println(arith.func(5, 6));
	Gener<Double> am = (a,b)-> a-b;
	System.out.println(am.func(10.9, 6.8));
}
}
