package com.veri.test;

public class Sum {
	public void add(int a, int b) {
		return;
	}
}
