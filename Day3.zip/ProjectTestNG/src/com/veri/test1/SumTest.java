package com.veri.test1;

import org.testng.annotations.Optional;
import org.testng.annotations.Test;

import com.beust.jcommander.Parameters;

import org.testng.annotations.Test;

public class SumTest {

  @Test(priority=2,invocationCount=1)
  
  public void addTest() {
    //throw new RuntimeException("Test not implemented");
	  System.out.println("Addition is done here");
  }
  
  @Test(priority=1,enabled=false)
  public void addTest1() {
    //throw new RuntimeException("Test not implemented");
	  System.out.println("Addition2 is done here");
  }
  
  @Test()
  @Parameters({"a","b"})
  public void getText(@Optional("user") String name,@Optional("jai") String name1)
  {
	  System.out.println("End");
  }
  
  
}
