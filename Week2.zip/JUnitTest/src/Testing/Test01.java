package Testing;

public class Test01 {
int sum(int a,int b)
{
	return a+b;
}
 
}
