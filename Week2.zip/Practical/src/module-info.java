/**
 * 
 */
/**
 * 
 */
module Practical {
}