package practice;

import java.util.Scanner;

abstract class Test1 {
	public static void main(String[] args) {
		int b =10000;
		int amt;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the amount");
		amt = sc.nextInt();
		System.out.println("Balance is:"+(b-amt));
}}