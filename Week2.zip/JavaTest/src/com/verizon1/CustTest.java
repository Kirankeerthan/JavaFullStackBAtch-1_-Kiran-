package com.verizon1;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CustTest {
Customer c;
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
		c = new Customer();
	}

	@AfterEach
	void tearDown() throws Exception {
		c=null;
	}

	@Test
	void test() {
		//fail("Not yet implemented");
		assertEquals(c.getMsg(),"kiran");
	}

}
