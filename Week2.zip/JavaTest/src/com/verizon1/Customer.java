package com.verizon1;

public class Customer {

	public String getMsg() {
		// TODO Auto-generated method stub
		return "kiran";
	}

}
