package com.verizon1;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class DemoSum1Test {

	@Test
	void testSum() {
		DemoSum1 ds=new DemoSum1();
		assertEquals(ds.sum(4,3),7);
		//fail("Not yet implemented");
	}

}
