package com.verizon1;

public class DemoSum1 {
int sum(int a,int b)
{
	return a+b;
}
int pro(int a,int b)
{
	return a*b;
}

}
