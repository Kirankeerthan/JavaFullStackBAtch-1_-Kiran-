package com.verizon1;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class DemoSum1Test2 {
	DemoSum1 ds1;
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		System.out.println("Before Testing the method");
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		System.out.println("After Testing the method");
	}

	@BeforeEach
	void setUp() throws Exception {
		 ds1 = new DemoSum1();	
		 System.out.println("Object created");
	}

	@AfterEach
	void tearDown() throws Exception {
		ds1=null;
		System.out.println("Object Destroyed");
	}

	@Test
	void testSum() {
		
		assertEquals(ds1.sum(5, 5),10);
		//fail("Not yet impleme");
	}

	@Test
	void testPro() {
		assertEquals(ds1.pro(5, 5),25);
		//fail("Not yet implemented");
	}

}
