package com.collection;

import java.util.List;

public class CourseDemo {
public static void main(String[] args) {
	Course c1 = new Course(40,"angular",500.00);
	Course c2 = new Course(40,"react",600.00);
	CourseService cs = new CourseServiceImp();
	System.out.println(cs.addCourse(c1));
	System.out.println(cs.addCourse(c2));
	List<Course> returnedList = cs.listCourses();
	for(Course c:returnedList)
		System.out.println(c);
}
}
