package com.collection;


import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

public class CollExam {
	public static void main(String[] args) {
		
	
/*List ex = new ArrayList();
ex.add("rakesh");
ex.add(23);
ex.add(23.007);
ex.add(LocalDate.now());
ex.size();
System.out.println(ex);
ex.remove(3);
ex.contains(23);*/
		
	/*	Set<Object> s= new TreeSet<>();
		s.add(32);
		s.add(45);
		s.add(46);
		s.add(34);
	System.out.println(s);
	Iterator i= s.iterator();
	s.forEach(x->System.out.println(x));*/

		Map<Integer,String> mis = new HashMap();
		mis.put(1, "kiran");
		mis.put(2, "Lion");
		mis.put(5, null);
		System.out.println(mis);
		Set keys = mis.keySet();
		System.out.println(keys);
		Collection cs =mis.values();
		System.out.println(cs);

	}
}