package com.collection;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class CourseServiceImp implements CourseService {
List<Course> courseList = new ArrayList<>();
public String addCourse(Course c)
{
	return "Successfully Added";
}
public String deleteCourse(Integer cid)
{
	Iterator i= courseList.iterator();
	while(i.hasNext())
	{
		Course course= (Course)i.next();
		if(course.id == cid)
			i.remove();
	}
	return "Course deleted";
}
public String updateCourse(Integer cid)
{
	Iterator i = courseList.iterator();
	while(i.hasNext()) {
		Course course = (Course)i.next();
		if(course.id==cid)
			course.fee = course.fee+1000;
		
	}
	return "Ok";
}
public List<Course> listCourses()
{
	return courseList;
}


}


