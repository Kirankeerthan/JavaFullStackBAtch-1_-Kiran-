package com.example.crudOperation.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.crudOperation.module.Plan;

@Repository
public interface PlanDao extends JpaRepository<Plan,Integer> {

}
